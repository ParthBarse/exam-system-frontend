import React, { useState, useEffect } from "react";
import pic from "./favicon.png";

function AdmitCard() {
  const [item, setItem] = useState({}); // State to store the data fetched from the API

  useEffect(() => {
    const uuid = "YOUR_UUID"; // Replace with the actual UUID

    // Fetch data from the API endpoint
    fetch(`https://mcf-backend.vercel.app/api/getReportCard/${uuid}`)
      .then((response) => response.json())
      .then((data) => setItem(data))
      .catch((error) => console.error("Error fetching data:", error));
  }, []); // The empty dependency array ensures that this effect runs only once when the component mounts

  return (
    <div className="flex flex-col">
      <button
        onClick={(e) => window.print()}
        className="no-print bg-blue-500 hover:bg-blue-700 text-white py-1 px-2 rounded"
      >
        Print
      </button>
      <section className="bg-gray-100 flex items-center justify-center max-w-4xl mx-auto p-2">
        <div className="w-full bg-white shadow-md p-8 rounded-md">
          <div className="admit-card border-4 p-4 mb-4">
            <div className="BoxA border-1 p-4 mb-4">
              <div className="flex justify-between">
                <div className="w-1/4 flex items-center mr-16">
                  <h5 className="text-xl font-bold">ENTRANCE_CARD</h5>
                </div>
                <div className="w-3/4 flex justify-around ml-14">
                  <h5 className="text-4xl font-bold p-2 border">
                    MARSHAL CADET FORCE
                  </h5>
                  <p className="font-xl"></p>
                </div>
              </div>
            </div>
            <div className="BoxC border-1 p-4 mb-4">
              <div className="flex">
                <div className="w-full flex justify-around">
                  <h5 className="font-bold">Enrollment No : {item.uuid}</h5>
                </div>
              </div>
            </div>
            <div className="BoxD border-1 p-4 mb-4">
              <div className="flex">
                <div className="w-1/2">
                  <table className="table table-bordered w-full border-collapse">
                    <tbody>
                      <tr>
                        <td className="font-bold border p-2">
                          Student Name :{" "}
                          <span className="font-normal">{item.First + " " + item.last}</span>{" "}
                        </td>
                      </tr>
                      <tr>
                        <td className="font-bold border p-2">
                          Sex : <span className="font-normal">Male</span>
                        </td>
                      </tr>
                      <tr>
                        <td className="font-bold border p-2">
                          Father Name :{" "}
                          <span className="font-normal">{item.fathername}</span>
                        </td>
                      </tr>
                      <tr>
                        <td className="font-bold border p-2">
                          ENROLLMENT NO :{" "}
                          <span className="font-normal">{item.uuid}</span>{" "}
                        </td>
                      </tr>
                      <tr>
                        <td colSpan="2" className="font-bold border p-2">
                          Address :{" "}
                          <span className="font-normal">{item.address}</span>
                        </td>
                      </tr>
                      <tr>
                        <td className="border p-2">
                          <b>Camp: </b>{item.camp}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="w-1/2 flex flex-col items-center justify-center">
                  <img
                    src={pic}
                    className="w-42 h-44 mb-2 border"
                    alt="Student Photo"
                  />
                  <img src={""} className="p-2 border" alt="Signature" />
                </div>
              </div>
            </div>
            <div className="BoxE border-1 p-2 mb-4 text-center">
              <div className="flex">
                <div className="w-full">
                  <h5>PICK-UP POINT : {item.pickup} , {item.city} , INDIA</h5>
                  {/* <p> point here <br />city ,  INDIA</p> */}
                </div>
              </div>
            </div>
            <div className="BoxF border-1 p-2 mb-4 text-center">
              <div className="flex">
                <div className="w-full">
                  <table className="table table-bordered w-full">
                    <thead>
                      <tr>
                        <th>Camp</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>{item.camp}</td>
                        <td>{item.start_date}</td>
                        <td>{item.end_date}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <footer className="text-center mt-2">
              <p className="text-gray-600">
                ***************************** MARSHAL CADET FORCE
                *****************************
              </p>
            </footer>
          </div>
        </div>
      </section>
    </div>
  );
}

export default AdmitCard;
